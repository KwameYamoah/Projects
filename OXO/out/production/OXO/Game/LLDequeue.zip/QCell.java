package Game;

public class QCell<T>
{
    private T data;
    private QCell<T> next;
    private QCell<T> prev;
    public QCell(T data, QCell<T> prev, QCell<T> next)
    {
        this.data = data;
        this.prev = prev;
        this.next = next;
    }

    public void setNext(QCell<T> next) {
        this.next = next;
    }

    public void setPrev(QCell<T> prev) {
        this.prev = prev;
    }

    public QCell<T> getNext() {
        return next;
    }

    public QCell<T> getPrev() {
        return prev;
    }

    public T getData() {
        return data;
    }
}