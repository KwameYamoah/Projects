package Game;
// createdeq, isempty, left, right, addleft, addright, removeleft and removeright

public interface Dequeue<T> {
    public void addLeft(T o);

    public void addRight(T o);

    public void removeLeft();

    public void removeRight();

    public T left();

    public T right();

    public boolean isEmpty();
}

class DequeueException extends RuntimeException {
    DequeueException(String s) {
        super("Tried to apply " + s + " to empty queue");
    }
}
