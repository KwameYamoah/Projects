package Game;

import org.omg.PortableServer.THREAD_POLICY_ID;

import java.sql.SQLOutput;

public class LLDequeue<T> implements Dequeue<T>
{
    private QCell<T> front;
    private QCell<T> back;

    public LLDequeue(){
        front = null;
        back = null;
    }


    @Override
    public void addLeft(T o) {
        if(isEmpty()){
            QCell<T> cell = new QCell<>(o,null,null);
            front = cell;
            back = cell;
        }
        else {
            QCell<T> newCell = new QCell<>(o, null, front);
            front.setPrev(newCell);
            front = newCell;
        }
    }

    @Override
    public void addRight(T o) {
        if(isEmpty()){
            QCell<T> cell = new QCell<>(o,null,null);
            front = cell;
            back = cell;
        } else {
            QCell<T> newCell = new QCell<>(o, back, null);
            back.setNext(newCell);
            back = newCell;
        }
    }

    @Override
    public void removeLeft() {
        if(isEmpty()) throw new DequeueException("removeLeft");

        front = front.getNext();
        front.setPrev(null);


    }

    @Override
    public void removeRight() {
        if(isEmpty()) throw new DequeueException("removeRight");
        back = back.getPrev();
        back.setNext(null);


    }

    @Override
    public T left() {
        if(isEmpty()) throw new DequeueException("left");
        return front.getData();
    }

    @Override
    public T right() {
        if(isEmpty()) throw new DequeueException("right");
        return back.getData();
    }

    @Override
    public boolean isEmpty() {
        return  back ==null;
    }

    @Override
    public String toString() {
        QCell<T> tempFront = front;
        StringBuilder s = new StringBuilder();
        s.append("<");

        while(tempFront.getNext() != null){
            s.append(tempFront.getData());
            s.append(",");
            tempFront = tempFront.getNext();
        }
        s.append(tempFront.getData());

        s.append(">");
        return s.toString();
    }

    public static void main(String[] args) {
        LLDequeue<Integer> llDequeue = new LLDequeue<>();
        llDequeue.addLeft(3);
        llDequeue.addLeft(2);
        llDequeue.addRight(4);
        llDequeue.addLeft(1);
        System.out.println("Before");
        System.out.println(llDequeue);
        System.out.println("After");
        llDequeue.removeRight();
        System.out.println(llDequeue);

        llDequeue.addRight(4);

        System.out.println(llDequeue);



    }

}